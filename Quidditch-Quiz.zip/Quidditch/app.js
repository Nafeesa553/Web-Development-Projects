const questionEl = document.querySelector(".question");
const choicesList = document.querySelector(".choicesList");
const quizStartButton = document.querySelector(".quizStartButton");
const quizContainer = document.querySelector(".quizContainer");
const nextBtn = document.querySelector(".nextBtn");

const url = "https://opentdb.com/api.php?amount=10&category=18&difficulty=hard&type=multiple";

let questions = [];
let currentIndex = 0;
let score = 0;


async function getQuestions() {
    try {
        const response = await fetch(url);
        const data = await response.json();

        questions = data.results.map(q => ({
            question: decodeHTML(q.question),
            correctAnswer: decodeHTML(q.correct_answer),
            options: shuffle([
                ...q.incorrect_answers.map(ans => decodeHTML(ans)),
                decodeHTML(q.correct_answer)
            ])
        }));

        showQuestion();

    } catch (err) {
        console.log("Error:", err);
    }
}


function showQuestion() {
    const q = questions[currentIndex];

    questionEl.innerText = q.question;
    choicesList.innerHTML = "";

    q.options.forEach(option => {
        const li = document.createElement("li");
        li.innerText = option;

        li.addEventListener("click", () => checkAnswer(option, q.correctAnswer, li));

        choicesList.appendChild(li);
    });
}


function checkAnswer(selected, correct, element) {
    const allOptions = document.querySelectorAll(".choicesList li");

    allOptions.forEach(li => li.style.pointerEvents = "none");

    if (selected === correct) {
        element.style.backgroundColor = "green";
        score++;
    } else {
        element.style.backgroundColor = "red";

        allOptions.forEach(li => {
            if (li.innerText === correct) {
                li.style.backgroundColor = "green";
            }
        });
    }
}

nextBtn.addEventListener("click", () => {
    currentIndex++;

    if (currentIndex < questions.length) {
        showQuestion();
    } else {
        showScore();
    }
});


function showScore() {
    questionEl.innerText = ` Your Score: ${score}/${questions.length}`;
    choicesList.innerHTML = "";
    nextBtn.style.display = "none";
    
}


quizStartButton.addEventListener("click", () => {
    quizContainer.style.display = "block";
    quizStartButton.style.display = "none";
    getQuestions();
});


function shuffle(arr) {
    const newArr = [...arr];

    for (let i = newArr.length - 1; i > 0; i--) {
        let j = Math.floor(Math.random() * (i + 1));
        [newArr[i], newArr[j]] = [newArr[j], newArr[i]];
    }

    return newArr;
}


function decodeHTML(html) {
    const txt = document.createElement("textarea");
    txt.innerHTML = html;
    return txt.value;
}