const button = document.querySelector(".button");
const input = document.querySelector("#date");
const result = document.querySelector("#result");

button.addEventListener("click", () => {
    let DOB = input.value;
    console.log(DOB);
    let dateOfBirth = new Date(DOB)

    const today = new Date();


    let age = today.getFullYear() - dateOfBirth.getFullYear();
    let monthdiff = today.getMonth() - dateOfBirth.getMonth();
    if (monthdiff < 0 || monthdiff === 0 && today.getdate < dateOfBirth.getDate) {
        age--
    }

    result.innerText = `your age is ${age}`


})
document.addEventListener("keypress",(e)=>{
    if(e.key == "Enter"){
        button.click();
    }
})