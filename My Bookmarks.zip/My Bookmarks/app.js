const button = document.querySelector(".button");
const input = document.querySelector(".input");
const bookmarkList = document.querySelector(".bookmarkList");
let bookmarksArray = JSON.parse(localStorage.getItem("bookmarks")) || [];


function displayBookmarks() {
    bookmarkList.innerHTML = "";

    bookmarksArray.forEach((url, index) => {
        let newInputList = document.createElement("li");
        let links = document.createElement("a");
        let div = document.createElement("div")
        let editButton = document.createElement("button")
        let delButton = document.createElement("button")



        div.setAttribute("class", "buttonsUl")
        editButton.setAttribute("class", " buttons ")
        editButton.setAttribute("id", "editBtn")
        delButton.setAttribute("class", "buttons")
        delButton.setAttribute("id", "delBtn")


        editButton.innerText = "Edit";
        delButton.innerText = "Delete"
        links.setAttribute("href", url);
        links.setAttribute("target", "_blank")
        links.innerText = url;

        bookmarkList.append(newInputList);
        newInputList.append(links);
        newInputList.append(div);
        div.append(editButton);
        div.append(delButton);


        editButton.addEventListener("click", () => {

            let newUrl = prompt("Edit URL:", url);
            if (newUrl) {
                bookmarksArray[index] = newUrl;
                saveToLocal();
                displayBookmarks();
            }
        })
        delButton.addEventListener("click", () => {
            bookmarksArray.splice(index, 1);
            saveToLocal();
            displayBookmarks();
        });

    });

}



button.addEventListener("click", () => {
    if (input.value != "") {
        let url = input.value;
        bookmarksArray.push(url);
        saveToLocal();
        input.value = ""
        displayBookmarks();

    }
})

function saveToLocal() {
    localStorage.setItem("bookmarks", JSON.stringify(bookmarksArray));
}

document.addEventListener("keypress", (e) => {
    if (e.key == "Enter") {
        button.click();
    }
})

displayBookmarks();






