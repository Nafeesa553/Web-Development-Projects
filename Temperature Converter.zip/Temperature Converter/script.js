let tempF = document.querySelector("#farenheit");
let tempC= document.querySelector("#celsius");

let button = document.querySelector(".button");

button.addEventListener("click",()=>{
    
    let farenheit = (tempC.value *(9/5)) +32;
    tempF.value = farenheit;


})
document.addEventListener("keypress",(e)=>{
    if(e.key == "Enter"){
        button.click();
    }
})